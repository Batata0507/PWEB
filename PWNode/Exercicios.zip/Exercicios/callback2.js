function exibeMensagensNaOrdem(mensagem, callback){
    console.log(mensagem);
    callback();
}
exibeMensagensNaOrdem('Essa é a primeira mesagem exibida na ordem', function(){
    console.log('Essa e a segunda mensagem exibida na ordem');
})