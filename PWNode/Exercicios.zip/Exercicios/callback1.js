const prompt= require('prompt-sync')();
// parenteses indicam que estamos eecutando a função prompt-sync. Ao Fazer 
//isso, a função retorna um valor, que é uma nova função que pode ser usada para criar prompts
function saudacao(nome){
    console.log('OI '+ nome);
}
function entradaNome(callback){
    let nome = prompt('Digite seu nome');
    callback(nome); // chamada da função callback
}
entradaNome(saudacao);
// obter o nome do usuario através de uma caixa de dialogo e em seguida cha a função de callback;