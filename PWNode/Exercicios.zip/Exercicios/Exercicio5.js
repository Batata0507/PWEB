let eventos = require('events');//Atribuição da classe Evetemitter a uma variavel
let EmissorEventos = eventos.EventEmitter;// O emissor de eventos encontra-se na 
let ee = new EmissorEventos();

ee.on('dados',function(fecha){
    console.log(fecha);
})

ee.emit('dadis','primeira vez'+ Date.now());

setInterval(function(){
    ee.emit('dados',Date.now());
},500);

