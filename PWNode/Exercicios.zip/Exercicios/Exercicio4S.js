const fs = require ('fs');// carregando modulo filesystem
const data = fs.readFileSync('file.txt');
console.log(data.toString());